#!/bin/bash
#Port Monitoring
#Zabbix template Addition API#
#Monitoring_type(PORT)|ApplicationName|PortNumber|HostName|PollingInterval|Severity(in number)|trigger_sampling|workgroup|ApplicationName(without special character but - and _ allowed)|DMZ instance name
#Error message if one or more parameters are blank
###################################################
# Verson:2.0
# Author:Anirudh Chikara
###################################################
i=1
today=$(date);
template_creation="/etc/httpd/zabbixselfservice/Output/port_template_creation"
template_add="/etc/httpd/zabbixselfservice/Output/port_template_add.log"
auth_token="65df51fe8b23198b3f65e51463094554"

####################################################
#13. zabbix_host_update_api
####################################################

zabbix_host_update_api()
{
        j=0
        x=0
        k=2
        l=2
        count_=1
        _count=1
        echo "$today: starting zabbix_host_update_api function for row $row_no" >> $template_add
        echo "$today: content-> $hg_count : $t_count: $template_id_response: $hostgroup_id_response: $host_id_response " >> $template_add
        if [ -z "$hostgroup_id_response" ] || [ -z "$template_id_response" ]|| [ -z "$host_id_response" ] ;
        then
        errormsg="Error: Missing parameters.(Missing value(s) -> Hostgroup id: '$hostgroup_id_response' and template_id_response: '$template_id_response' and hostid: '$host_id_response')"
        today=$(date);
        echo "$today: $errormsg" >> $template_add
        exit;
        fi
        if [ $t_count == "0" ]
        then
                template_id_new='{ "templateid":"'${template_id_response}'" }'
        else
                template_id_new='{ "templateid":"'${template_id_response}'" },'
        fi
json=$(
        echo '{'
                echo '"jsonrpc": "2.0",'
                echo '"method": "host.update",'
                                echo '"params": {'
                                echo '"hostid": "'$host_id_response'",'
                                echo '"groups": ['
                echo '{ "groupid":"'${hostgroup_id_response}'" },'
                while [ $j -lt $hg_count ]
                        do
                                _hostgroup_id=`echo $host_get_response | awk -v m=$k -F 'groupid' '{print $m}' | awk -F '"' '{print $3}'`
                                ml='{ "groupid":"'${_hostgroup_id}'" }'
        if (( ${count_} < ${hg_count} )); then
                ml="${ml},"
        fi
        let "count_=count_+1"
        echo $ml
        j=$((j+1))    # increments $i
        k=$((k+1))
                done
        echo '],'
        echo '"templates":['
                echo '{ "templateid":"'${template_id_response}'" },'
            while [ $x -lt $t_count ]
                        do
                                _template_id=`echo $host_get_response | awk -v n=$l -F 'templateid' '{print $n}' | awk -F '"' '{print $3}'`
                                ml_temp='{ "templateid":"'${_template_id}'" }'
        if (( ${_count} < ${t_count} )); then
                ml_temp="${ml_temp},"
        fi
        let "_count=_count+1"
        echo $ml_temp
        x=$((x+1))    # increments $i
        l=$((l+1))
                done
        echo ']'
    echo '},'
    echo '"auth": "'$auth_token'",'
    echo '"id": 1'
        echo '}'
)
        host_update_response=$(curl -s -w '\n' -X POST -H 'Content-Type: application/json-rpc' -d "$json" https://zabbixmonstage.optum.com/zabbix/api_jsonrpc.php)
        json_check=`echo $host_response | grep -i invalid`
        if [ ! -z "$json_check" ]
        then
                echo "$today: Error in JSON at host_update_api function: $json_check" >> $template_add
        exit;
        fi
        echo "$today: end of host_update_api function for row $row_no" >> $template_add
}

######################################
#12. Zabbix Host Addition API
######################################
zabbix_create_host_api ()
{
        echo "$today: starting zabbix_create_host_api function for row $row_no" >> $template_add
        ##pass parameters in the same manner always
        echo "$today: content-> $_proxy : $_ipaddress " >> $template_add
        if [ -z "$_proxy" ] || [ -z "$_ipaddress" ];
        then
        errormsg="Error: Missing parameters.(Missing value(s) -> ProxyId: '$_proxy' IPAddress: '$_ipaddress')"
        today=$(date);
        echo "$today: $errormsg" >> $template_add
        exit;
        fi
        json='{
                "jsonrpc": "2.0",
                "method": "host.create",
                "params": {
                        "host": "'$template_app_name'",
                        "proxy_hostid": "'$_proxy'",
                        "interfaces": [
                                {
                "type": 1,
                "main": 1,
                "useip": 1,
                "ip": "'$_ipaddress'",
                "dns": "",
                "port": "10050"
                                }
                        ],
                        "groups": [
                                {
                "groupid": "'$hostgroup_id_response'"
                                }
                        ],
        "tags": [
            {
                "tag": "APP",
                "value": "'$app_name'"
            }
        ],
        "templates": [
            {
                "templateid": "'$template_id_response'"
            }
        ]
    },
    "auth": "'$auth_token'",
    "id": 1
}'
        host_response=$(curl -s -w '\n' -X POST -H 'Content-Type: application/json-rpc' -d "$json" https://zabbixmonstage.optum.com/zabbix/api_jsonrpc.php)
        host_id_response=`echo $host_response | awk -F '"' '{print $10}'`
        json_check=`echo $host_response | grep -i invalid`
        if [ ! -z "$json_check" ]
        then
        echo "$today: Error in JSON at zabbix_create_host_api function: $json_check" >> $template_add
        exit;
        fi
        echo $host_response:$host_id_response>> $template_add
        echo "$today: end of zabbix_create_host_api function for row $row_no" >> $template_add
}

######################
#11.host Check
######################
zabbix_get_host_api ()
{
        echo "$today: starting zabbix host check api function for row $row_no" >> $template_add
        echo "$today: content check parameter-> $template_app_name" >> $template_add
        if [ -z "$template_app_name" ];
        then
                errormsg="Error: Missing parameters.(Missing value(s) -> Application Name: '$template_app_name')"
                echo "$today: $errormsg" >> $template_add
        exit;
        fi
        json='
        {
                "jsonrpc": "2.0",
                "method": "host.get",
                "params": {
			"output": ["hostid"],
			"selectGroups": "extend",
			"selectParentTemplates":
				[
					"templateid",
					"name"
				],
                        "filter":
                        {
                                "host":
                                [
                                        "'$template_app_name'"
                                ]
                        }
                },
                "auth": "'$auth_token'",
                "id": 1
        }'
        host_get_response=$(curl -s -w '\n' -X POST -H 'Content-Type: application/json-rpc' -d "$json" https://zabbixmonstage.optum.com/zabbix/api_jsonrpc.php)
        host_id_response=`echo $host_get_response | awk -F 'hostid' '{print $2}' | awk -F '"' '{print $3}'`
	hg_count=$(echo $host_get_response | grep -o 'groupid' | wc -l)
	t_count=$(echo $host_get_response | grep -o 'templateid' | wc -l)
        json_check=`echo $host_get_response | grep -i invalid`
        if [ ! -z "$json_check" ]
        then
                echo "$today: Error in JSON at zabbix_get_host_api function: $json_check" >> $template_add
                exit;
        elif [ -z "$host_id_response" ]
        then
                zabbix_create_host_api $_proxy $_ipaddress    #6. zabbix_create_host_api function calling.
        else
                echo "host already exists and checking and updating the host" >> $template_add
		echo $host_get_response:$hg_count:$t_count >> $template_add
		zabbix_host_update_api $hg_count $t_count $template_id_response $hostgroup_id_response $host_id_response
        fi
        echo "$today: end of zabbix_get_host_api function for row $row_no" >> $template_add
}

######################################
#10.Zabbix Add item's trigger API
######################################

zabbix_add_trigger_api ()
{
        echo "$today: starting zabbix_add_trigger_api function for row $row_no" >> $template_add
        ##pass parameters in the same manner always
        echo "$today: content-> $_trigger_name $severity $_trigger_expression $template_app_name $_trigger_comment $workgroup application_name" >> $template_add
        if [ -z "$_trigger_name" ] || [ -z "$severity" ] || [ -z "$_trigger_expression" ] || [ -z "$template_app_name" ] || [ -z "$_trigger_comment" ] || [ -z "$application_name" ];
        then
                errormsg="Error: Missing parameters.(Missing value(s) -> trigger name: '$_trigger_name' & severity: '$severity' & trigger expression '$_trigger_expression' & application name '$application_name' & trigger comment '$_trigger_comment' && template_app_name '$template_app_name' )"
                echo "$today: $errormsg" >> $template_add
                exit;
        fi
        json='
        {
                "jsonrpc": "2.0",
                "method": "trigger.create",
                "params": [
                {
                        "description": "'$_trigger_name'",
                        "expression": "'$_trigger_expression'",
                        "priority":     "'$severity'",
                        "comments": "'$_trigger_comment'",
                        "tags": [
                        {
                                "tag": "OBJECTINSTANCE",
                                "value": "'$application_name'"
                        },
                        {
                                "tag": "DOMAIN",
                                "value": "'$domain'"
                        },
                        {
                                "tag": "WORKGROUP",
                                "value": "'$workgroup'"
                        },
			{
                                "tag": "OBJECTNAME",
                                "value": "'$objectname_tag'"
                        }
                        ]
                }
                ],
                "auth": "'$auth_token'",
                "id": 1
        }'
        trigger_response=$(curl -s -w '\n' -X POST -H 'Content-Type: application/json-rpc' -d "$json" https://zabbixmonstage.optum.com/zabbix/api_jsonrpc.php)
        trigger_id_response=`echo $trigger_response | awk -F '"' '{print $10}'`
        json_check=`echo $trigger_response | grep -i invalid`
        if [ ! -z "$json_check" ]
        then
                echo "$today: Error in JSON at zabbix_add_trigger_api function: $json_check" >> $template_add
                exit;
        fi
        echo $trigger_response:$trigger_id_response >> $template_add
        echo "$today: end of zabbix_add_trigger_api function for row $row_no" >> $template_add
}

#########################################
#9.Zabbix item's trigger check API
#########################################

zabbix_get_trigger_api ()
{
        echo "$today: starting zabbix_get_trigger_api function for row $row_no" >> $template_add
        ##pass parameters in the same manner always
        echo "$today: content-> $template_id_response $_trigger_name $severity" >> $template_add
        if [ -z "$template_id_response" ] || [ -z "$_trigger_name" ] || [ -z "$severity" ];
        then
                errormsg="Error: Missing parameters.(Missing value(s) -> template id: '$template_id_response' & trigger name: '$_trigger_name' & severity: '$severity')"
                echo "$today: $errormsg" >> $template_add
                exit;
        fi
        json='
        {
                "jsonrpc": "2.0",
                "method": "trigger.get",
                "params": {
                        "templateids": "'$template_id_response'",
                        "filter": {"description": ["'$_trigger_name'"],
                                   "priority": ["'$severity'"]
                                  },
                "output": "extend",
                "selectFunctions": "extend"
                          },
                "auth": "'$auth_token'",
                "id": 1
        }'
        trigger_get_response=$(curl -s -w '\n' -X POST -H 'Content-Type: application/json-rpc' -d "$json" https://zabbixmonstage.optum.com/zabbix/api_jsonrpc.php)
        trigger_id_response=`echo $trigger_get_response | awk -F 'triggerid' '{print $2}' | awk -F '"' '{print $3}'`
        json_check=`echo $trigger_get_response | grep -i invalid`
        if [ ! -z "$json_check" ]
        then
                echo "$today: Error in JSON at zabbix_get_trigger_api function: $json_check" >> $template_add
                exit;
                elif [ -z "$trigger_id_response" ]
                then
                        zabbix_add_trigger_api $_trigger_name $severity $_trigger_expression $application_name $_trigger_comment $workgroup #application_name =  URL for Web Monitoring
                else
                        echo "$today: Zabbix trigger already exists: '$_trigger_name'" >> $template_add
                fi
        echo $trigger_get_response:$trigger_id_response >> $template_add
        echo "$today: end of zabbix_get_trigger_api function for row $row_no" >> $template_add
}

######################################
#8.Zabbix port item Addition API
######################################

zabbix_add_item_api ()
{
        echo "$today: starting zabbix_add_item_api function for row $row_no" >> $template_add
        ##pass parameters in the same manner always
        echo "$today: content-> $_item_name $_item_type $_item_key $_item_value_type $polling_interval $_item_history $_item_trend $zbxapplication_id_response $template_id_response" >> $template_add
        if [ -z "$_item_name" ] || [ -z "$_item_type" ] || [ -z "$_item_key" ] || [ -z "$_item_value_type" ] || [ -z "$polling_interval" ] || [ -z "$zbxapplication_id_response" ] || [ -z "$template_id_response" ] ;
        then
               errormsg="Error: Missing parameters.(Missing value(s) -> ItemName: '$_item_name' & ItemType: '$_item_type' & ItemValueType '$_item_value_type' & ItemInterval '$polling_interval' & ApplicationID '$zbxapplication_id_response' & TemplateId '$template_id_response')"
               echo "$today: $errormsg" >> $template_add
               exit;
       fi
        json='
        {
                "jsonrpc": "2.0",
                                                                "method": "item.create",
                                                                "params": {
                                                                "name": "'$_item_name'",
                                                                "type": "'$_item_type'",
                                                                "key_": "'$_item_key'",
                                                                "value_type": "'$_item_value_type'",
                                                                "delay": "'$polling_interval'",
                                                                "history": "'$_item_history'",
                                                                "trends": "'$_item_trend'",
                                                                "applications": ["'$zbxapplication_id_response'"],
                                                                "hostid": "'$template_id_response'"
                                },
        "auth": "'$auth_token'",
        "id": 1
        }'
        item_response=$(curl -s -w '\n' -X POST -H 'Content-Type: application/json-rpc' -d "$json" https://zabbixmonstage.optum.com/zabbix/api_jsonrpc.php)
        item_id_response=`echo $item_response | awk -F '"' '{print $10}'`
        json_check=`echo $item_response | grep -i invalid`
        if [ ! -z "$json_check" ]
        then
                echo "$today: Error in JSON at zabbix_add_item_api function: $json_check" >> $template_add
                echo $item_response >> $template_add
        exit;
        fi
        echo $item_response:$item_id_response >> $template_add
        echo "$today: end of zabbix_add_item_api function for row $row_no" >> $template_add
}

#######################
#7. Item Check
#######################
zabbix_get_item_api ()
{
        echo "$today: starting zabbix_get_item_api function for row $row_no" >> $template_add
        echo "$today: incoming parameters-> $_item_key $template_id_response" >> $template_add
        if [ -z "$template_id_response" ] || [ -z "$_item_key" ];
        then
                errormsg="Error: Missing parameters.(Missing value(s) -> Template id: '$template_id_response' and Item Key Value: '$_item_key')"
                echo "$today: $errormsg" >> $template_add
                exit;
        fi
        json='
        {
                                                "jsonrpc": "2.0",
                                                "method": "item.get",
                                                "params": {
                                                                "output": "extend",
                                                                "hostids": "'$template_id_response'",
                                                                "search": {
                                                                                                "key_": "'$_item_key'"
                                                                                                },
                                                                "sortfield": "name"
                                },
           "auth": "'$auth_token'",
           "id": 1
        }'
        item_get_response=$(curl -s -w '\n' -X POST -H 'Content-Type: application/json-rpc' -d "$json" https://zabbixmonstage.optum.com/zabbix/api_jsonrpc.php)
        item_id_response=`echo $item_get_response | awk -F 'itemid' '{print $2}' | awk -F '"' '{print $3}'`
        json_check=`echo $item_get_response | grep -i invalid`
        if [ ! -z "$json_check" ]
        then
                echo "$today: Error in JSON at zabbix_get_item_api function: $json_check" >> $template_add
                exit;
        elif [ -z "$item_id_response" ]
        then
                zabbix_add_item_api $_item_name $_item_type $_item_key $_item_value_type $polling_interval $_item_history $_item_trend $zbxapplication_id_response $template_id_response
        else
                echo "$today: Zabbix item already exists itemid: '$item_id_response'" >> $template_add
        fi
        echo "$today: end of zabbix_get_item_api function for row $row_no" >> $template_add
}

######################################
#6.Zabbix zbxapplication addition API
######################################

zabbix_add_zbxapplication_api ()
{
        echo "$today: starting zabbix_add_zbxapplication_api function for row $row_no" >> $template_add
        ##pass parameters in the same manner always
        echo "$today: content-> $template_id_response" >> $template_add
        if [ -z "$template_id_response" ];
        then
                errormsg="Error: Missing parameters.(Missing value(s) -> Template Id: '$template_id_response')"
                echo "$today: $errormsg" >> $template_add
        exit;
        fi
        json='{
                "jsonrpc": "2.0",
                "method": "application.create",
                "params": {
                        "name": "Port",
                        "hostid": "'$template_id_response'"
                },
                "auth": "'$auth_token'",
                "id": 1
        }'
        application_response=$(curl -s -w '\n' -X POST -H 'Content-Type: application/json-rpc' -d "$json" https://zabbixmonstage.optum.com/zabbix/api_jsonrpc.php)
        zbxapplication_id_response=`echo $application_response | awk -F '"' '{print $10}'`
        json_check=`echo $application_response | grep -i invalid`
        if [ ! -z "$json_check" ]
        then
                echo "$today: Error in JSON at zabbix_add_zbxapplication_api function: $json_check" >> $template_add
        exit;
        fi
        echo $application_name:$zbxapplication_id_response >> $template_add
        echo "$today: end of zabbix_add_zbxapplication_api function for row $row_no" >> $template_add
}


#######################
#5.zbxapplication Check
#######################

zabbix_get_zbxapplication_api ()
{
        echo "$today: starting zabbix_get_zbxapplication_api function for row $row_no" >> $template_add
        echo "$today: incoming parameters-> $template_id_response " >> $template_add
        if [ -z "$template_id_response" ];
        then
                errormsg="Error: Missing parameters.(Missing value(s) -> Template id: '$template_id_response')"
                echo "$today: $errormsg" >> $template_add
                exit;
        fi
        json='
        {
                "jsonrpc": "2.0",
                "method": "application.get",
                "params":
                {
                        "output": "extend",
                        "templateids": "'$template_id_response'",
                        "filter": {"name": ["Port"]},
                        "sortfield": "name"
                },
                "auth": "'$auth_token'",
                "id": 1
        }'
        zbxapplication_get_response=$(curl -s -w '\n' -X POST -H 'Content-Type: application/json-rpc' -d "$json" https://zabbixmonstage.optum.com/zabbix/api_jsonrpc.php)
        zbxapplication_id_response=`echo $zbxapplication_get_response | awk -F 'applicationid' '{print $2}' | awk -F '"' '{print $3}'`
        json_check=`echo $zbxapplication_get_response | grep -i invalid`
        if [ ! -z "$json_check" ]
        then
                echo "$today: Error in JSON at zabbix_get_zbaapplication_api function: $json_check" >> $template_add
                exit;
        elif [ -z "$zbxapplication_id_response" ]
        then
                zabbix_add_zbxapplication_api  $template_id_response     #2. zabbix_add_zbxapplication_api function calling and application_name =  Port
        else
                echo "$today: Zabbix application already exists" >> $template_add
        fi
        echo "$today: end of zabbix_get_zbaapplication_api function for row $row_no" >> $template_add
}


######################################
#4.Zabbix template Addition API
######################################

zabbix_add_template_api ()
{
        echo "$today: starting zabbix_add_template_api function for row $row_no" >> $template_add
        ##pass parameters in the same manner always
        echo "$today: content-> $app_name $hostgroup_id_response" >> $template_add
        if [ -z "$app_name" ] || [ -z "$hostgroup_id_response" ] || [ -z "$_template_name" ];
        then
        errormsg="Error: Missing parameters.(Missing value(s) -> Application Name: '$app_name' and HostGroup Id: '$hostgroup_id_response' and template name: '$_template_name' )"
        echo "$today: $errormsg" >> $template_add
        exit;
        fi
        json='{
                "jsonrpc": "2.0",
                "method": "template.create",
                "params": {
                "host": "'$_template_name'",
                "description": "'$app_name'",
                "groups": {
                        "groupid":"'$hostgroup_id_response'"
                },
                "tags": [
                {
                "tag": "CATEGORY",
                "value": "'$_category'"
                },
                {
                "tag": "OBJECTCLASS",
                "value": "'$_objectclass'"
                },
                {
                "tag": "OBJECTPARAMETER",
                "value": "'$_objectparameter'"
                }
                ]
                 },
    "auth": "'$auth_token'",
    "id": 1
                }'
    template_response=$(curl -s -w '\n' -X POST -H 'Content-Type: application/json-rpc' -d "$json" https://zabbixmonstage.optum.com/zabbix/api_jsonrpc.php)
    template_id_response=`echo $template_response | awk -F '"' '{print $10}'`
    json_check=`echo $template_response | grep -i invalid`
    if [ ! -z "$json_check" ]
    then
        echo "$today: Error in JSON at zabbix_add_template_api function: $json_check" >> $template_add
        exit;
    fi
    echo "Optum Template App Web monitoring - $app_name:$template_id_response" >> $template_add
    echo "$today: end of zabbix_add_template_api function for row $row_no" >> $template_add
}


#################
#3.Template Check
#################

zabbix_get_template_api ()
{
        echo "$today: starting zabbix_get_template_api function for row $row_no" >> $template_add
        echo "$today: incoming parameters-> $_template_name" >> $template_add
        if [ -z "$_template_name" ];
        then
                errormsg="Error: Missing parameters.(Missing value(s) -> Template name: '$_template_name')"
                echo "$today: $errormsg" >> $template_add
                exit;
        fi
        json='
        {
                "jsonrpc": "2.0",
                "method": "template.get",
                "params":
                {
                        "output": "extend",
                        "filter":
                        {
                                "host":
                                [
                                        "'$_template_name'"
                                ]
                        }
                },
                "auth": "'$auth_token'",
                "id": 1
        }'
        template_get_response=$(curl -s -w '\n' -X POST -H 'Content-Type: application/json-rpc' -d "$json" https://zabbixmonstage.optum.com/zabbix/api_jsonrpc.php)
        template_id_response=`echo $template_get_response | awk -F 'templateid' '{print $2}' | awk -F '"' '{print $3}'`
        json_check=`echo $template_get_response | grep -i invalid`
        if [ ! -z "$json_check" ]
        then
                echo "$today: Error in JSON at zabbix_get_template_api function: $json_check" >> $template_add
        exit;
        elif [ -z "$template_id_response" ]
        then
                zabbix_add_template_api $app_name $hostgroup_id_response       #2. zabbix_add_template_api function calling.
                zabbix_get_zbxapplication_api $template_id_response   # Check If Template Exists or not
        else
                zabbix_get_zbxapplication_api $template_id_response # Check If Template Exists or not
        fi
        echo "$today: end of zabbix_get_template_api function for row $row_no" >> $template_add
}

######################################
#2. Zabbix hostgroup Addition API
######################################
zabbix_add_hostgroup_api ()
{
        echo "$today: starting zabbix_add_hostgroup_api function for row $row_no" >> $template_add
        ##pass parameters in the same manner always
        echo "$today: content-> $_hostgroup_name" >> $template_add
        if [ -z "$_hostgroup_name" ];
        then
                errormsg="Error: Missing parameters.(Missing value(s) -> Hostgroup: '$_hostgroup_name' )"
                echo "$today: $errormsg" >> $template_add
        exit;
        fi
        json='
        {
                "jsonrpc": "2.0",
                "method": "hostgroup.create",
                "params":
                {
                        "name": "'$_hostgroup_name'"
                },
                "auth": "'$auth_token'",
                "id": 1
        }'
        hostgroup_response=$(curl -s -w '\n' -X POST -H 'Content-Type: application/json-rpc' -d "$json" https://zabbixmonstage.optum.com/zabbix/api_jsonrpc.php)
        hostgroup_id_response=`echo $hostgroup_response | awk -F '"' '{print $10}'`
        json_check=`echo $hostgroup_response | grep -i invalid`
        if [ ! -z "$json_check" ]
        then
                echo "$today: Error in JSON at zabbix_add_hostgroup_api function: $json_check" >> $template_add
        exit;
        fi
        echo $hostgroup_name:$hostgroup_id_response >> $template_add
        echo "$today: end of zabbix_add_hostgroup_api function for row $row_no" >> $template_add
}

##################
#1.HostGroup Check
##################
zabbix_get_hostgroup_api ()
{
        echo "$today: starting zabbix_get_hostgroup_api function for row $row_no" >> $template_add
        echo "$today: incoming parameters:-> $_hostgroup_name" >> $template_add
        if [ -z "$_hostgroup_name" ];
        then
                errormsg="Error: Missing parameters.(Missing value(s) -> hostgroup name: '$_hostgroup_name')"
                echo "$today: $errormsg" >> $template_add
                exit;
        fi
        json='
        {
                "jsonrpc": "2.0",
                "method": "hostgroup.get",
                "params":
                {
                        "output": "extend",
                        "filter":
                        {
                                "name":
                                [
                                        "'$_hostgroup_name'"
                                ]
                        }
                },
                "auth": "'$auth_token'",
                "id": 1
        }'
        hostgroup_get_response=$(curl -s -w '\n' -X POST -H 'Content-Type: application/json-rpc' -d "$json" https://zabbixmonstage.optum.com/zabbix/api_jsonrpc.php)
        hostgroup_id_response=`echo $hostgroup_get_response | awk -F '"' '{print $10}'`
        json_check=`echo $hostgroup_get_response | grep -i invalid`
        if [ ! -z "$json_check" ]
        then
                echo "$today: Error in JSON at zabbix_get_hostgroup_api function: $json_check" >> $template_add
        exit;
        elif [ -z "$hostgroup_id_response" ]
        then
                zabbix_add_hostgroup_api $_hostgroup_name        #5. zabbix_add_hostgroup_api function calling.
                zabbix_get_template_api $hostgroup_id_response    # Check If Template Exists or not
        else
                zabbix_get_template_api $hostgroup_id_response   # Check If Template Exists or not
        fi
        echo "$today: end of zabbix_get_hostgroup_api function for row $row_no" >> $template_add
}

##############################################################################################################
#-----------------------------------------------Beginning------------------------------------------------------
##############################################################################################################

if [ ! -f $template_creation ];
then
        echo "$today: ERROR: File:'$template_creation' doesn't exists." >> $template_add
        exit;
fi
echo "$today: File:'$template_creation' exists." >> $template_add
declare -a server_array
readarray server_array < /etc/httpd/zabbixselfservice/Output/port_template_creation # Include newline.

#########################
#Number of elements in the array or number of rows in inventory list.
#########################

count="${#server_array[@]}"
echo "$today: Number of rows in '$template_creation' file:: $count" >> $template_add

#########################
##Execute template creation function until $i equals to the number of elements in array.
#########################
#Monitoring_type(PORT)|ApplicationName|PortNumber|HostName|PollingInterval|Severity(in number)|trigger_sampling|workgroup|ApplicationName(without special character but - and _ allowed)|DMZ instance name

while [ $i -lt $count ]
do
        row_no=$((i+1)) # to add execution row number in log
        echo "$today: executing for row $row_no: ${server_array[i]}" >> $template_add
        IFS='|' read -r -a array <<< ${server_array[i]}
        monitoring_type=${array[0]}
        app_name=${array[1]}
        port_no=${array[2]}
        domain=${array[3]}
        polling_interval=${array[4]}
        severity=${array[5]}
        trigger_sampling=${array[6]}
        workgroup=${array[7]}
        template_app_name=${array[8]} # used in Template name and Hostname
        dmz=${array[9]}
	objectname_tag=${array[10]}
        application_name="Port"
        if [ -z "$dmz" ]
        then
                _proxy="10416"                                  #NON DMZ proxy ID
                _ipaddress="{\$NON_DMZ_PROXY_IP}"
                if [ $monitoring_type == "PORT" ]
                then
                        _hostgroup_name="SiteScope/Corp 1/Port/$app_name"
                else
                        echo "Wrong Monitoring Type, please use correct script" >> $template_add
                        exit;
                 fi
        else
                _proxy="10656"                                  # DMZ proxy ID
                _ipaddress="{\$DMZ_PROXY_IP}"
                if [ $monitoring_type == "PORT" ]
                then
                        _hostgroup_name=SiteScope/$dmz/Port/$app_name
                else
                        echo "Wrong Monitoring Type, please use correct script" >> $template_add
                        exit;
                 fi
        fi

        _category="Port Monitoring"
        _objectclass="Port Monitoring"
        _objectparameter="Status"
        _template_name_full="Optum Template Port -$template_app_name"
        _template_name=`echo "${_template_name_full:0:123}"`    #Truncating the template name upto 123 character
###################
#Host Group get/Check function call
###################

        zabbix_get_hostgroup_api $_hostgroup_name $row_no                       #4. Calling host group check API.

###################
#4. zabbix_add_Port_item_api function calling.
###################
                                
                                _item_name="Port $port_no monitoring on $domain"
                                _item_type="3"
                                _item_key="net.tcp.service[tcp,$domain,$port_no]"
                                _item_value_type="3"
                                _item_history="30d"
                                _item_trend="90d"
        zabbix_get_item_api $_item_name $_item_type $_item_key $_item_value_type $polling_interval $_item_history $_item_trend $zbxapplication_id_response $template_id_response


###################
#5. zabbix_add_trigger_api function calling.
###################

        _trigger_name="Port $port_no on host $domain is not responding from zabbix server"
        _trigger_expression="{$_template_name:net.tcp.service[tcp,$domain,$port_no].sum(#$trigger_sampling)}=0"
        _trigger_comment="Port $port_no on host $domain is not responding from zabbix server"
        zabbix_get_trigger_api $template_id_response $_trigger_name $severity $domain

###################
#5. zabbix_get_host_api function calling.
###################

    zabbix_get_host_api $template_app_name


        echo "$today: execution end for row $row_no: ${server_array[i]}" >> $template_add
        sleep 2
        i=$((i+1))    # increments $i
done
