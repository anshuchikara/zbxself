#!/bin/bash
#Zabbix template Addition API#
#Required incoming parameters
#Monitoring_type(WEB/PORT -ALL CAPS)|ApplicationName|URL|PollingInterval|RequiredString|StatusCode|Severity(in number)|workgroup|ApplicationName(without special character but - and _ allowed)|trigger_sampling|xml_data|DMZ instance name
# Error message if one or more parameters are blank
###################################################
# Verson:1.0
# Author:Anirudh Chikara
###################################################
i=1
today=$(date);
template_creation="/etc/httpd/zabbixselfservice/Output/ping_template_creation"
template_add="/etc/httpd/zabbixselfservice/Output/ping_template_add.log"
auth_token="46465ac40e017dd87bd4f935e94b8a1a"


######################################
#12. Zabbix Host Addition API
######################################
zabbix_create_host_api ()
{
        echo "$today: starting zabbix_create_host_api function for row $row_no" >> $template_add
        ##pass parameters in the same manner always
        echo "$today: content-> $host_name : $group_id : $ip_address : $proxy_id " >> $template_add
        if [ -z "$host_name" ] || [ -z "$group_id" ] || [ -z "$ip_address" ] || [ -z "$proxy_id" ] ;
        then
        errormsg="Error: Missing parameters.(Missing value(s) -> HostName: '$host_name' GroupId: '$group_id' IpAddress: '$ip_address' ProxyId: '$proxy_id' )"
        today=$(date);
        echo "$today: $errormsg" >> $template_add
        exit;
        fi
        json='{
		"jsonrpc": "2.0",
    		"method": "host.create",
    		"params": {
        		"host": "'$host_name'",
        		"interfaces": [
            			{
                		"type": 1,
		                "main": 1,
                		"useip": 1,
		                "ip": "'$ip_address'",
                		"dns": "",
		                "port": "10050"
            		}
        	],
        	"groups": [
            	{
                	"groupid": "'$group_id'"
            		}
        	],
	        "templates": [
        	    {
                	"templateid": "10546"
            		}
        	],
	        "inventory_mode": -1,
        	"proxy_hostid": "'$proxy_id'"
	    },
	    "auth": "'$auth_token'",
	    "id": 1
}'
        host_response=$(curl -s -w '\n' -X POST -H 'Content-Type: application/json-rpc' -d "$json" https://zabbixmonstage.optum.com/zabbix/api_jsonrpc.php)
        host_id_response=`echo $host_response | awk -F '"' '{print $10}'`
        json_check=`echo $host_response | grep -i invalid`
        if [ ! -z "$json_check" ]
        then
        echo "$today: Error in JSON at zabbix_create_host_api function: $json_check" >> $template_add
        exit;
        fi
        echo $host_response:$host_id_response>> $template_add
        echo "$today: end of zabbix_create_host_api function for row $row_no" >> $template_add
}

######################
#11.host Check
######################
zabbix_get_host_api ()
{
	hg_count="0"
	t_count="0"
	echo "$today: starting zabbix host check api function for row $row_no" >> $template_add
	echo "$today: content check parameter-> $host_name" >> $template_add
	if [ -z "$host_name" ];
	then
		errormsg="Error: Missing parameters.(Missing value(s) -> Host Name: '$host_name')"
		echo "$today: $errormsg" >> $template_add
	exit;
	fi
	json='
	{
		"jsonrpc": "2.0",
		"method": "host.get",
		"params": {
                	"filter": {
                        	 "host": [
                                        "'$host_name'"
                                	]
                         	}
                },
		"auth": "'$auth_token'",
		"id": 1
	}'
	host_get_response=$(curl -s -w '\n' -X POST -H 'Content-Type: application/json-rpc' -d "$json" https://zabbixmonstage.optum.com/zabbix/api_jsonrpc.php)
	host_id_response=`echo $host_get_response | awk -F 'hostid' '{print $2}' | awk -F '"' '{print $3}'`
	hg_count=$(echo $host_get_response | grep -o 'groupid' | wc -l)
	t_count=$(echo $host_get_response | grep -o 'templateid' | wc -l)
	json_check=`echo $host_get_response | grep -i invalid`
	if [ ! -z "$json_check" ]
	then
		echo "$today: Error in JSON at zabbix_get_host_api function: $json_check" >> $template_add
		exit;
	elif [ -z "$host_id_response" ]
	then
		zabbix_create_host_api $host_name $group_id $ip_address $proxy_id   #6. zabbix_create_host_api function calling.
	else
		echo "host already exists and checking and updating the host" >> $template_add
		echo $host_get_response:$hg_count:$t_count >> $template_add
	#	zabbix_host_update_api $hg_count $t_count $template_id_response $hostgroup_id_response $host_id_response
	fi
	echo "$today: end of zabbix_get_host_api function for row $row_no" >> $template_add
}
##################################
#-----------Beginning------------#
##################################

if [ ! -f $template_creation ];
then
	echo "$today: ERROR: File:'$template_creation' doesn't exists." >> $template_add
	exit;
fi
echo "$today: File:'$template_creation' exists." >> $template_add
declare -a server_array
readarray server_array < /etc/httpd/zabbixselfservice/Output/ping_template_creation # Include newline.

#########################
#Number of elements in the array or number of rows in inventory list.
#########################

count="${#server_array[@]}"
echo "$today: Number of rows in '$template_creation' file:: $count" >> $template_add

#########################
##Execute template creation function until $i equals to the number of elements in array.
#########################

while [ $i -lt $count ]
do
	row_no=$((i+1)) # to add execution row number in log
	echo "$today: executing for row $row_no: ${server_array[i]}" >> $template_add
	IFS='|' read -r -a array <<< ${server_array[i]}
	monitoring_type=${array[0]}
	host_name=${array[1]}
	group_id=${array[2]}
	ip_address=${array[3]}
	proxy_id=${array[4]}
###################
#Host Group get/Check function call
###################
	if [ $monitoring_type == "PING" ]
                then
			zabbix_get_host_api $host_name
		else
        		echo "wrong monitoring type"
			exit;
	fi

	echo "$today: execution end for row $row_no: ${server_array[i]}" >> $template_add
        sleep 2
        i=$((i+1))    # increments $i
done
